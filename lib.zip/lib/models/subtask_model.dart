class SubTask {
  final String id;
  late String title;
  bool isCompleted;

  SubTask({required this.id ,required this.title, required this.isCompleted});
}