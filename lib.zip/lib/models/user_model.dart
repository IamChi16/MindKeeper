class Users{
  final String uid;
  final String email;
  final String name;

  Users({
    required this.uid,
    required this.email,
    required this.name,
  });
}