import 'package:flutter/material.dart';
import '../app/app_export.dart';

class AppDecoration {
  static BoxDecoration get bGColor => BoxDecoration(
        color: theme.colorScheme.onPrimary,
      );
}

class BorderRadiusStyle{}